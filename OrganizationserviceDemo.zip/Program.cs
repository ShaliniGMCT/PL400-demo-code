﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.PowerPlatform.Dataverse.Client;
using CrmEarlyBound;


namespace orgser1
{
    class Program
    {
        static string connectionString = "AuthType=OAuth; Url=https://org85d1fa7f.api.crm.dynamics.com;UserName=admin@M365x14357749.onmicrosoft.com;Password=~JVo0b;5%7D7kVv(;AppId = 51f81489-12ee-4a9e-aaae-a2591f45987d;RedirectUri = app://58145B91-0C36-4500-8554-080854F2AC97;LoginPrompt=Auto;RequireNewInstance = True";

        static void Main(string[] args)
        {
            using (ServiceClient serviceClient = new ServiceClient(connectionString))
            {
                if (serviceClient.IsReady)
                {
                    WhoAmIResponse response =
                        (WhoAmIResponse)serviceClient.Execute(new WhoAmIRequest());

                    Console.WriteLine("User ID is {0}.", response.UserId);

                    // Set Condition Values
                    //var query_kg_basicsalary = 4000;

                    // Instantiate QueryExpression query
                    var query = new QueryExpression("kg_employee");
                    query.TopCount = 50;
                    // Add columns to query.ColumnSet
                    query.ColumnSet.AddColumns("kg_basicsalary", "kg_departmentassigned", "kg_firstname", "kg_jobtitle", "kg_name");

                    // Add conditions to query.Criteria
                   // query.Criteria.AddCondition("kg_basicsalary", ConditionOperator.GreaterEqual, query_kg_basicsalary);

                    EntityCollection empls = serviceClient.RetrieveMultiple(query);
                    foreach(kg_Employee record in empls.Entities)
                    {
                        Console.WriteLine(record.Id.ToString() + " "+ record.kg_FirstName+ " " + record.kg_JobTitle);
                    }

                }
                else
                {
                    Console.WriteLine(
                        "A web service connection was not established.");
                }
            }

            // Pause the console so it does not close.
            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();
        }
    }
}
